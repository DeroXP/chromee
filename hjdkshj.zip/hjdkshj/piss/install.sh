wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O chrome.deb
apt-get install -y ./chrome.deb
rm chrome.deb